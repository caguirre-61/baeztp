cd 11820
ssh -p23 11820@mattprofe.com.ar 
yes
ssh -p 23 11820@mattprofe.com.ar
echo. > comandos.txt
type nul > comandos.txt
touch comandos.txt
ssh -p 23 11820@mattprofe.com.ar
touch comandos.txt
mkdir ACTIVIDADES
touch comandos.txt
ls
ls
cd ACTIVIDADES/
cd CLASE_12
la
ls
ls app-clima/
nano index.php 
cd ..
nano index.php
rm index.php
cd ClASE_12
fg
cd CLASE_12
ls
nano index.php
rm index.php
nano refresh.js 
rm refresh.js interface.css datos.json 
ls
cd app-clima/
ls
nano refresh,js
ls
nano refresh.js 
cd ..
cd ..
mkdir CLASE_10
cd CLASE_10
sftp 11820@mattprofe.com.ar
sftp 11820@mattprofe.com.ar
ls
nano backup.sh
chmod +x backup.sh 
./backup.sh
cd ..
chmod -R 755 ~/ACTIVIDADES/CLASE_10
