<?php
include('conexion.php');

// Si ya está logueado, se va directo al panel
if (isset($_SESSION['idUsuario'])) {
    header("Location: panel.php");
    exit();
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conexion, $_POST['email']);
    $password = mysqli_real_escape_string($conexion, $_POST['password']);

    if (!empty($email) && !empty($password)) {
        // Buscamos al usuario en la base de datos
        $query = "SELECT * FROM usuarios WHERE email = '$email' AND password = '$password'";
        $resultado = mysqli_query($conexion, $query);

        if (mysqli_num_rows($resultado) == 1) {
            $usuario_data = mysqli_fetch_assoc($resultado);
            $_SESSION['idUsuario'] = $usuario_data['idUsuario']; // O el nombre exacto del campo clave
            $_SESSION['email'] = $usuario_data['email'];
            
            header("Location: panel.php");
            exit();
        } else {
            $error = "Email o contraseña incorrectos.";
        }
    } else {
        $error = "Por favor, completa todos los campos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>webgenerator Camilo Aguirre</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <main class="contenedor-formulario">
        <h1>webgenerator Camilo Aguirre</h1>
        
        <?php if (!empty($error)): ?>
            <div class="alerta-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <form action="login.php" method="POST">
            <div class="campo">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="campo">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">Ingresar</button>
        </form>

        <p><a href="register.php">¿No tenés cuenta? Registrate acá</a></p>
    </main>
</body>
</html>
