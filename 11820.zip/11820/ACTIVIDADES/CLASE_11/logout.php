<?php
include('conexion.php');

// Vaciamos todas las variables de sesión
$_SESSION = array();

// Si se desea destruir la cookie de sesión por completo, se invalida
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Se destruye la sesión física en el servidor
session_destroy();

// Redirección directa e inmediata al login
header("Location: login.php");
exit();
?>
