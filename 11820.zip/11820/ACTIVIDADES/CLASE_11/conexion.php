<?php
$host = "mattprofe.com.ar";
$usuario = "11820";
$password = "buey.abeto.camion"; 
$bd = "11820";

$conexion = mysqli_connect($host, $usuario, $password, $bd);

if (!$conexion) {
    die("Error de conexión: " . mysqli_connect_error());
}

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
