<?php
include('conexion.php');

// Seguridad: Si no está logueado, afuera al login
if (!isset($_SESSION['idUsuario'])) {
    header("Location: login.php");
    exit();
}

$idUsuario = $_SESSION['idUsuario'];
$emailUsuario = $_SESSION['email'];
$mensaje = "";

// --- LÓGICA 1: CREAR WEB ---
if (isset($_POST['crear_web'])) {
    $nombre_web = trim(mysqli_real_escape_string($conexion, $_POST['nombre_web']));
    if (!empty($nombre_web)) {
        $dominio = $nombre_web . $idUsuario;

        // Comprobamos si el dominio ya existe en la tabla webs
        $query_check = "SELECT * FROM webs WHERE dominio = '$dominio'";
        $res_check = mysqli_query($conexion, $query_check);

        if (mysqli_num_rows($res_check) == 0) {
            // Insertamos en la base de datos
            $query_insert = "INSERT INTO webs (dominio, idUsuario) VALUES ('$dominio', '$idUsuario')";
            if (mysqli_query($conexion, $query_insert)) {
                // Ejecutamos el script de shell pasándole el dominio como parámetro
                shell_exec("sh wix.sh $dominio");
                $mensaje = "Web generada correctamente de manera exitosa.";
            }
        } else {
            $mensaje = "El dominio ya existe en el sistema.";
        }
    }
}

// --- LÓGICA 2: ACCIONES (ELIMINAR Y DESCARGAR) ---
if (isset($_GET['accion']) && isset($_GET['dominio'])) {
    $dom_accion = mysqli_real_escape_string($conexion, $_GET['dominio']);
    
    // Verificación de seguridad básica (que la web sea del usuario, a menos que sea admin)
    $es_admin = ($emailUsuario === "admin@server.com");
    $condicion_usuario = $es_admin ? "" : "AND idUsuario = '$idUsuario'";
    
    $query_verificar = "SELECT * FROM webs WHERE dominio = '$dom_accion' $condicion_usuario";
    $res_verificar = mysqli_query($conexion, $query_verificar);

    if (mysqli_num_rows($res_verificar) == 1) {
        if ($_GET['accion'] === 'eliminar') {
            // 1. Borrar de la base de datos
            $query_delete = "DELETE FROM webs WHERE dominio = '$dom_accion'";
            mysqli_query($conexion, $query_delete);
            
            // 2. Borrar la carpeta física del servidor de forma recursiva
            shell_exec("rm -rf $dom_accion");
            header("Location: panel.php");
            exit();
        } 
        
        if ($_GET['accion'] === 'descargar') {
            $zip_file = $dom_accion . ".zip";
            // Comprimimos la carpeta del dominio en un archivo .zip
            shell_exec("zip -r $zip_file $dom_accion");
            
            if (file_exists($zip_file)) {
                // Forzamos la descarga del archivo ZIP mediante headers de PHP
                header('Content-Type: application/zip');
                header('Content-Disposition: attachment; filename="' . basename($zip_file) . '"');
                header('Content-Length: ' . filesize($zip_file));
                flush();
                readfile($zip_file);
                // Borramos el zip temporal creado para no ocupar espacio de más
                unlink($zip_file);
                exit();
            }
        }
    }
}

// --- LÓGICA 3: LISTAR WEBS ---
if ($emailUsuario === "admin@server.com") {
    // Si es administrador, listamos absolutamente todas las webs
    $query_listado = "SELECT * FROM webs";
} else {
    // Si es usuario estándar, listamos sólo las de su propiedad
    $query_listado = "SELECT * FROM webs WHERE idUsuario = '$idUsuario'";
}
$resultado_webs = mysqli_query($conexion, $query_listado);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido a tu panel</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <header class="panel-header">
        <h1>Bienvenido a tu panel</h1>
        <div class="usuario-info">
            <a href="logout.php" class="btn-logout">Cerrar sesión de <?php echo $idUsuario; ?></a>
        </div>
    </header>

    <main class="panel-contenido">
        <?php if (!empty($mensaje)): ?>
            <div class="alerta-info"><?php echo $mensaje; ?></div>
        <?php endif; ?>

        <!-- Formulario de Creación -->
        <section class="seccion-crear">
            <form action="panel.php" method="POST">
                <label for="nombre_web">Generar Web de:</label>
                <input type="text" id="nombre_web" name="nombre_web" placeholder="Nombre de tu web" required>
                <button type="submit" name="crear_web">Crear web</button>
            </form>
        </section>

        <hr>

        <!-- Listado de Sitios Web creados -->
        <section class="seccion-listado">
            <h2>Tus sitios web generados</h2>
            <ul class="lista-webs">
                <?php if (mysqli_num_rows($resultado_webs) > 0): ?>
                    <?php while ($web = mysqli_fetch_assoc($resultado_webs)): ?>
                        <li class="item-web">
                            <!-- Enlace al index interno de la carpeta del dominio generado -->
                            <a href="<?php echo $web['dominio']; ?>/index.html" target="_blank" class="link-dominio">
                                <?php echo $web['dominio']; ?>
                            </a>
                            <div class="acciones-web">
                                <a href="panel.php?accion=descargar&dominio=<?php echo $web['dominio']; ?>" class="btn-accion descargar">descargar web</a>
                                <a href="panel.php?accion=eliminar&dominio=<?php echo $web['dominio']; ?>" class="btn-accion eliminar" onclick="return confirm('¿Seguro que querés eliminar esta web por completo?');">Eliminar</a>
                            </div>
                        </li>
                    <?php endwith; ?>
                <?php else: ?>
                    <p class="sin-resultados">Aún no creaste ninguna web en el sistema.</p>
                <?php endif; ?>
            </ul>
        </section>
    </main>
</body>
</html>
