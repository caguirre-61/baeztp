<?php
include('conexion.php');

// Si ya está logueado, se va directo al panel
if (isset($_SESSION['idUsuario'])) {
    header("Location: panel.php");
    exit();
}

$mensaje = "";
$tipo_mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conexion, $_POST['email']);
    $password = mysqli_real_escape_string($conexion, $_POST['password']);
    $password_rep = mysqli_real_escape_string($conexion, $_POST['password_rep']);

    if ($password !== $password_rep) {
        $mensaje = "Las contraseñas ingresadas no coinciden.";
        $tipo_mensaje = "error";
    } else {
        // Verificar si el email ya existe
        $query_check = "SELECT * FROM usuarios WHERE email = '$email'";
        $resultado_check = mysqli_query($conexion, $query_check);

        if (mysqli_num_rows($resultado_check) > 0) {
            $mensaje = "El email ya se encuentra registrado.";
            $tipo_mensaje = "error";
        } else {
            // Insertar el nuevo usuario
            $query_insert = "INSERT INTO usuarios (email, password) VALUES ('$email', '$password')";
            if (mysqli_query($conexion, $query_insert)) {
                $mensaje = "¡Registro exitoso! Redireccionando al login...";
                $tipo_mensaje = "exito";
                // Redirección limpia tras 2 segundos para que el usuario pueda ver el mensaje de éxito
                header("refresh:2;url=login.php");
            } else {
                $mensaje = "Hubo un error al registrar el usuario.";
                $tipo_mensaje = "error";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrarte es simple.</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <main class="contenedor-formulario">
        <h1>Registrarte es simple.</h1>

        <?php if (!empty($mensaje)): ?>
            <div class="alerta-<?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
        <?php endif; ?>

        <form action="register.php" method="POST">
            <div class="campo">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="campo">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="campo">
                <label for="password_rep">Repetir Contraseña:</label>
                <input type="password" id="password_rep" name="password_rep" required>
            </div>
            <button type="submit">Registrarse</button>
        </form>

        <p><a href="login.php">¿Ya tenés cuenta? Iniciá sesión</a></p>
    </main>
</body>
</html>
