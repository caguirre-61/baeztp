<?php
if (($handle = fopen("nomina.csv", "r")) !== FALSE) {
    echo '<table border="1" cellpadding="5" cellspacing="0" 
style="width: 100%; text-align: center;">';

    if (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        echo '<tr>';
        foreach ($data as $header) {
            echo '<th style="font-weight: bold;">' . 
htmlspecialchars($header) . '</th>';
        }
        echo '</tr>';
    }

    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        echo '<tr>';
        foreach ($data as $cell) {
            echo '<td>' . htmlspecialchars($cell) . '</td>';
        }
        echo '</tr>';
    }
    
    echo '</table>';

    fclose($handle);
} else {
    echo "Error al abrir el archivo.";
}
?>
<?php
$archivo = 'nomina.csv';
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $apellido = $_POST['apellido'] ?? '';
    $nombre = $_POST['nombre'] ?? '';
    $anio = $_POST['anio'] ?? '';
    $ciudad = $_POST['ciudad'] ?? '';
    $provincia = $_POST['provincia'] ?? '';

    $nuevoId = 1000; 
    if (file_exists($archivo) && filesize($archivo) > 0) {
        $lineas = file($archivo, FILE_IGNORE_NEW_LINES | 
FILE_SKIP_EMPTY_LINES);
        $ultimaLinea = end($lineas);
        $datosUltimaLinea = explode(',', $ultimaLinea);
        $nuevoId = (int)$datosUltimaLinea[0] + 1;
    }

    $nuevoRegistro = [$nuevoId, $apellido, $nombre, $anio, $ciudad, 
$provincia];

    $fp = fopen($archivo, 'a');
    if ($fp) {
        fputcsv($fp, $nuevoRegistro);
        fclose($fp);
        $mensaje = "Registro exitoso. ID asignado: $nuevoId";
    } else {
        $mensaje = "Error al abrir el archivo.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nómina - Agregar Alumno</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: 
#f4f4f4; padding: 20px; }
        .form-container { background: white; padding: 20px; 
border-radius: 8px; max-width: 400px; margin: auto; box-shadow: 0 0 10px 
rgba(0,0,0,0.1); }
        input { width: 100%; padding: 8px; margin: 10px 0; border: 1px 
solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background-color: #28a745; 
color: white; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background-color: #218838; }
        .alert { color: #155724; background-color: #d4edda; padding: 
10px; border-radius: 4px; margin-bottom: 15px; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Nuevo Alumno</h2>
    
    <?php if ($mensaje): ?>
        <div class="alert"><?php echo $mensaje; ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="apellido" placeholder="Apellido" 
required>
        <input type="text" name="nombre" placeholder="Nombre" required>
        <input type="number" name="anio" placeholder="Año de Nacimiento" 
required>
        <input type="text" name="ciudad" placeholder="Ciudad" required>
        <input type="text" name="provincia" placeholder="Provincia" 
required>
        <button type="submit">Agregar a Nómina</button>
    </form>
    <br>
    <a href="nomina.php">Actualizar lista</a>
</div>

</body>
</html>
