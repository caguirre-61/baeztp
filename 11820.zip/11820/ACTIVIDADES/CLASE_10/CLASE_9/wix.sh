#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

echo "Ingrese nombre del nuevo proyecto, luego presione la tecla enter:"
read -r PROYECTO

if [ -z "$PROYECTO" ]; then
    echo "❌ Error: El nombre no puede estar vacío."
    exit 1
fi

while true; do
    echo -e "\nTipo de proyecto a 
crear:\nVacío\nEstructura\nEjemplo\nSalir\n"
    echo -n "Seleccione una opción: "
    read -r OPCION

    case "$OPCION" in
        "Vacío")
            # Forzamos la creación de la carpeta con /bin/mkdir
            /bin/mkdir -p "$PROYECTO"
            # Creamos el index.php TOTALMENTE VACÍO (con >)
            printf "" > "$PROYECTO/index.php"
            
            echo "Se creó el proyecto $PROYECTO, en blanco"
            exit 0 ;;
            
        "Estructura")
            /bin/mkdir -p "$PROYECTO" "$PROYECTO/css" "$PROYECTO/js" 
"$PROYECTO/img" "$PROYECTO/includes"
            printf "" > "$PROYECTO/index.php"
            
            echo "Se creó el proyecto $PROYECTO, con estructura"
            exit 0 ;;
            
        "Ejemplo")
            /bin/mkdir -p "$PROYECTO" "$PROYECTO/css" "$PROYECTO/js" 
"$PROYECTO/img" "$PROYECTO/includes"
            
            # Estructura HTML5 real inyectada directamente al index.php 
sin comandos externos
            echo "<!DOCTYPE html>" > "$PROYECTO/index.php"
            echo "<html lang=\"es\">" >> "$PROYECTO/index.php"
            echo "<head>" >> "$PROYECTO/index.php"
            echo "    <meta charset=\"UTF-8\">" >> "$PROYECTO/index.php"
            echo "    <title>$PROYECTO</title>" >> "$PROYECTO/index.php"
            echo "</head>" >> "$PROYECTO/index.php"
            echo "<body>" >> "$PROYECTO/index.php"
            echo "    <h1>$PROYECTO</h1>" >> "$PROYECTO/index.php"
            echo "</body>" >> "$PROYECTO/index.php"
            echo "</html>" >> "$PROYECTO/index.php"
            
            # Archivos internos vacíos
            printf "" > "$PROYECTO/css/estilos.css"
            printf "" > "$PROYECTO/js/scripts.js"
            
            echo "Se creó el proyecto $PROYECTO, con ejemplos"
            exit 0 ;;
            
        "Salir")
            echo "Saliendo sin cambios."
            exit 0 ;;
        *)
            echo "⚠️ Opción no válida. Intente de nuevo." ;;
    esac
done
