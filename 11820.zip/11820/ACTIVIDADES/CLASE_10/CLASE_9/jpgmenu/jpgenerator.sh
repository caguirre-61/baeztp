#!/bin/bash

# 1. Validar que se hayan recibido los 2 parámetros obligatorios
if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Error: Faltan parámetros."
    echo "Uso: $0 [nombre_carpeta] [cantidad_archivos]"
    exit 1
fi

# 2. Asignar los parámetros a variables claras
# $1 es el primer argumento (ej: "fotos") y $2 es el segundo (ej: 
"1024")
CARPETA_DESTINO="$1"
CANTIDAD_ARCHIVOS="$2"

# Obtener la ruta exacta de donde estás parado ahora mismo
DIR_ACTUAL="$PWD"

# Forzar la creación de la carpeta con la ruta que indicó el usuario
/bin/mkdir -p "$DIR_ACTUAL/$CARPETA_DESTINO" 2>/dev/null || mkdir -p 
"$DIR_ACTUAL/$CARPETA_DESTINO"

echo "Generando $CANTIDAD_ARCHIVOS archivos en: 
$DIR_ACTUAL/$CARPETA_DESTINO"

# Bucle nativo adaptado para usar la variable de cantidad
for ((i=1; i<=CANTIDAD_ARCHIVOS; i++))
do
    :> "$DIR_ACTUAL/$CARPETA_DESTINO/$i.jpg"
done

echo "¡Proceso de guardado finalizado!"
