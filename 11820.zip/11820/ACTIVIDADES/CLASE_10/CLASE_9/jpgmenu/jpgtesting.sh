#!/bin/bash

while true; do
    echo "---------------------------"
    echo "Testing de scripts JPG:"
    echo "1. Generar JPGs"
    echo "2. Ordenar JPGs"
    echo "3. Eliminar JPGs"
    echo "4. Salir"
    echo "---------------------------"
    echo -n "Seleccione una opción: "
    read opcion

    case "$opcion" in
        1)
            echo "--- GENERAR JPGs ---"
            echo -n "Ingrese el nombre de la carpeta: "
            read carpeta
            echo -n "Ingrese la cantidad de archivos a crear: "
            read cantidad
            
            ./jpgenerator.sh "$carpeta" "$cantidad"
            
            echo "Se ha generado $carpeta y $cantidad JPGs dentro."
            ;;
            
        2)
            echo "--- ORDENAR JPGs ---"
            echo -n "Ingrese el nombre de la carpeta: "
            read carpeta
            
            if [ -d "$carpeta" ]; then
                # Contar archivos en la carpeta sin contar subcarpetas
                cantidad_actual=$(find "$carpeta" -maxdepth 1 -type f | 
wc -l)
                echo "$carpeta contiene $cantidad_actual archivos"
                
                echo -n "Ingrese cantidad de archivos por carpeta: "
                read cant_por_carpeta
                
                ./order.sh "$carpeta" "$cant_por_carpeta"
            else
                echo "Error: La carpeta '$carpeta' no existe."
            fi
            ;;
            
        3)
            echo "--- ELIMINAR JPGs ---"
            echo -n "Ingrese el nombre de la carpeta: "
            read carpeta
            
            ./jpgdelete.sh "$carpeta"
            ;;
            
        4)
            echo "Saliendo del script. ¡Hasta luego!"
            exit 0
            ;;
            
        *)
            echo "Opción no válida. Intente nuevamente."
            ;;
    esac
    
    echo ""
    echo -n "Presione [Enter] para continuar..."
    read
    clear
done
