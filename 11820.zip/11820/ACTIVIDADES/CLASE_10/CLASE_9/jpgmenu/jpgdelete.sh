#!/bin/bash

# Reparar el PATH por si las dudas en este entorno
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

CARPETA="$1"

# Validar que se haya pasado el parámetro de la carpeta
if [ -z "$CARPETA" ]; then
    echo "Uso: $0 <ubicacion/nombre_de_carpeta>"
    exit 1
fi

# Validar si la carpeta realmente existe
if [ ! -d "$CARPETA" ]; then
    echo "❌ Error: La carpeta '$CARPETA' no existe."
    exit 1
fi

# Bucle infinito para obligar a responder "Si" o "No" de forma exacta 
(case-sensitive)
while true; do
    echo "Realmente quiere eliminar $CARPETA y todo su contenido?-Si/No"
    read -r respuesta

    if [ "$respuesta" = "No" ]; then
        echo "Operación cancelada. No se borró nada."
        exit 0
    elif [ "$respuesta" = "Si" ]; then
        # Rompemos el bucle y procedemos a borrar
        break
    fi
    # Cualquier otra cosa (si, no, SI, NO, 20, etc.) hará que el bucle 
continúe
done

echo "Procediendo al borrado seguro..."
contador_borrados=0

# Entrar a la carpeta para procesar los archivos uno por uno
cd "$CARPETA" || exit 1

# Recorrer todos los archivos de la carpeta
for archivo in *; do
    # Evitar errores si la carpeta está completamente vacía
    if [ "$archivo" = "*" ] && [ ! -e "$archivo" ]; then
        continue
    fi
    
    # Mostrar el nombre del archivo que se está eliminando
    echo "Eliminando archivo: $archivo"
    
    # Borrar el archivo de forma nativa
    /bin/rm "$archivo" 2>/dev/null || rm "$archivo"
    
    ((contador_borrados++))
done

# Volver a la carpeta anterior para poder eliminar la carpeta vacía
cd ..

# Eliminar la carpeta contenedora (ya vacía) usando rmdir para seguridad
/bin/rmdir "$CARPETA" 2>/dev/null || rmdir "$CARPETA" || /bin/rm -rf 
"$CARPETA"

echo "✔ Proceso finalizado con éxito."
echo "Se eliminaron un total de $contador_borrados archivos y la carpeta 
'$CARPETA'."
