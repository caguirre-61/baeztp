#!/bin/bash

# Creamos la carpeta backup si no existe
mkdir -p backup

while true; do
    echo "========================================="
    echo "           MENU DE BACKUP                "
    echo "========================================="
    echo "1) Carpeta (Comprimir una carpeta específica)"
    echo "2) Todo (Comprimir todas las clases)"
    echo "3) Salir"
    echo "========================================="
    read -p "Seleccione una opción [1-3]: " opcion

    case $opcion in
        1)
            echo ""
            read -p "Ingrese el NOMBRE de la carpeta a comprimir: " NOMBRE
            
            # Verificamos si la carpeta realmente existe fuera de backup
            if [ -d "../$NOMBRE" ] || [ -d "$NOMBRE" ]; then
                # Ajustamos la ruta por si estás parado dentro de CLASE_10
                RUTA_ORIGEN=""
                if [ -d "$NOMBRE" ]; then RUTA_ORIGEN="$NOMBRE"; else RUTA_ORIGEN="../$NOMBRE"; fi

                # Creamos la subcarpeta con el NOMBRE dentro de backup
                mkdir -p "backup/$NOMBRE"

                # Buscamos la última versión existente para determinar el número consecutivo
                VERSION=1
                while [ -f "backup/$NOMBRE/${NOMBRE}_V${VERSION}.zip" ]; do
                    VERSION=$((VERSION + 1))
                done

                # Nombre del archivo final
                ARCHIVO_ZIP="${NOMBRE}_V${VERSION}.zip"

                echo "Comprimiendo la carpeta '$NOMBRE' en 'backup/$NOMBRE/$ARCHIVO_ZIP'..."
                # Comprimimos (-r de forma recursiva) y nos aseguramos de guardarlo en su subcarpeta
                zip -r "backup/$NOMBRE/$ARCHIVO_ZIP" "$RUTA_ORIGEN"
                echo "¡Backup de la carpeta finalizado con éxito!"
            else
                echo "Error: La carpeta '$NOMBRE' no existe."
            fi
            echo ""
            ;;
            
        2)
            echo ""
            # Creamos la carpeta 'todo' dentro de backup
            mkdir -p backup/todo

            # Buscamos la última versión existente para el backup general
            VERSION=1
            while [ -f "backup/todo/todo_V${VERSION}.zip" ]; do
                VERSION=$((VERSION + 1))
            done

            ARCHIVO_ZIP="todo_V${VERSION}.zip"
            echo "Comprimiendo todas las carpetas (excepto backup) en 'backup/todo/$ARCHIVO_ZIP'..."

            # Usamos zip -r excluyendo la carpeta backup (-x)
            # Volvemos una carpeta atrás para agarrar todas las clases de ACTIVIDADES
            zip -r "backup/todo/$ARCHIVO_ZIP" ../* -x "*/backup*" -x "*backup*"
            
            echo "¡Backup completo finalizado con éxito!"
            echo ""
            ;;
            
        3)
            echo "Finalizando el script. ¡Hasta luego!"
            exit 0
            ;;
            
        *)
            echo "Opción inválida. Por favor, elija 1, 2 o 3."
            echo ""
            ;;
    esac
done
