#!/bin/bash

# Intentamos forzar el PATH al extremo
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

# Validamos parámetros
if [ $# -ne 2 ]; then
    echo "Uso: $0 <mascara> <carpeta_de_trabajo>"
    exit 1
fi

MASCARA=$1
CARPETA=$2

if [ ! -d "$CARPETA" ]; then
    echo "Error: La carpeta '$CARPETA' no existe."
    exit 1
fi

echo "Renombrando archivos en '$CARPETA'..."

# Recorremos los archivos
for archivo in "$CARPETA"/*; do
    if [ -f "$archivo" ]; then
        
        # TRUCO NATIVO: Esto hace lo mismo que basename pero sin usar el 
comando basename
        nombre_base="${archivo##*/}"
        
        # Renombramos usando la ruta absoluta de mv por si acaso
        /bin/mv "$archivo" "$CARPETA/${MASCARA}_${nombre_base}" 2>/dev/null || 
mv "$archivo" "$CARPETA/${MASCARA}_${nombre_base}"
    fi
done

echo "¡Renombrado masivo finalizado!"
