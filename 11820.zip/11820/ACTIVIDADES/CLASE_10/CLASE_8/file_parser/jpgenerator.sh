#!/bin/bash

# Obtener la ruta exacta de donde estás parado ahora mismo
DIR_ACTUAL="$PWD"

# Forzar la creación de la carpeta con ruta completa
/bin/mkdir -p "$DIR_ACTUAL/fotos" 2>/dev/null || mkdir -p "$DIR_ACTUAL/fotos"

echo "Generando 1024 archivos en: $DIR_ACTUAL/fotos"

# Bucle nativo e infalible
for i in {1..1024}
do
    :> "$DIR_ACTUAL/fotos/$i.jpg"
done

echo "¡Proceso de guardado finalizado!"
