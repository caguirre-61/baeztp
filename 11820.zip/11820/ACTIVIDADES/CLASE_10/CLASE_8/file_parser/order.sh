#!/bin/bash

CANTIDAD_MAX=$1
CARPETA_PADRE=$2

# Validación de parámetros
if [ -z "$CANTIDAD_MAX" ] || [ -z "$CARPETA_PADRE" ]; then
    echo "Uso: $0 <cantidad> <carpeta>"
    exit 1
fi

# Movernos a la carpeta usando la ruta del sistema
cd "$PWD/$CARPETA_PADRE" || exit 1

numero_carpeta=1
contador_archivos=0

# Crear la primera subcarpeta contenedora
/bin/mkdir -p "$numero_carpeta" 2>/dev/null || mkdir -p "$numero_carpeta"

# Recorrer los archivos .jpg de forma nativa
for elemento in *.jpg; do
    # Evitar errores si no hay archivos
    [ -e "$elemento" ] || continue
    
    # Si completamos la tanda, pasamos a la siguiente subcarpeta
    if [ "$contador_archivos" -eq "$CANTIDAD_MAX" ]; then
        ((numero_carpeta++))
        /bin/mkdir -p "$numero_carpeta" 2>/dev/null || mkdir -p 
"$numero_carpeta"
        contador_archivos=0
    fi
    
    # Mover el archivo usando la ruta absoluta de mv
    /bin/mv "$elemento" "$numero_carpeta/" 2>/dev/null || mv "$elemento" 
"$numero_carpeta/"
    ((contador_archivos++))
done

echo "✔ ¡Organización terminada de forma nativa!"
