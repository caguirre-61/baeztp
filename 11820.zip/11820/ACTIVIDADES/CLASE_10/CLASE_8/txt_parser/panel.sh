#!/bin/bash
echo "<!DOCTYPE html><html><head><title>Panel</title></head><body><h1>Listado de Alumnos</h1>" > alumnos.html
echo "<h2>Grupo G1</h2><ul>" >> alumnos.html
echo "<li><a href=\"../CLASE_7/Herrera Lautaro Ezequiel\">Herrera Lautaro Ezequiel</a></li>" >> alumnos.html
echo "<li><a href=\"../CLASE_7/Delport Franco Gabriel\">Delport Franco Gabriel</a></li>" >> alumnos.html
echo "</ul><h2>Grupo G2</h2><ul>" >> alumnos.html
echo "<li><a href=\"../CLASE_7/Perez Juan Carlos\">Perez Juan Carlos</a></li>" >> alumnos.html
echo "<li><a href=\"../CLASE_7/Gomez Maria Belen\">Gomez Maria Belen</a></li>" >> alumnos.html
echo "</ul><h2>Resumen de Datos (Log)</h2><pre>" >> alumnos.html
if [ -f "datos.log" ]; then cat datos.log >> alumnos.html; else echo "No se encontro datos.log" >> alumnos.html; fi
echo "</pre></body></html>" >> alumnos.html
echo "✔ Archivo alumnos.html generado con exito."
