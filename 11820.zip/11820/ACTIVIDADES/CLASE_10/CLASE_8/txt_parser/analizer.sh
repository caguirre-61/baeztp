#!/bin/bash

RUTA_TXT="71alumnos.txt"

if [ ! -f "$RUTA_TXT" ]; then
    echo "Error: No se encontró el archivo en $RUTA_TXT"
    exit 1
fi

# Cambiar IFS para leer líneas completas (respetando espacios iniciales)
IFS_BAK=$IFS
IFS=$'\n'

echo "--- Analizando el archivo renglón por renglón ---"
for renglon in $(cat "$RUTA_TXT"); do
    echo "Línea: $renglon"
done

IFS=$IFS_BAK
