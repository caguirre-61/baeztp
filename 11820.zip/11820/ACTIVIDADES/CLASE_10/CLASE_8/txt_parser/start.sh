#!/bin/bash

# Validar si el archivo existe
if [ ! -f "71alumnos.txt" ]; then
    echo "❌ ERROR: No se encuentra el archivo '71alumnos.txt' en esta 
carpeta."
    exit 1
fi

# Inicializar contadores
TOTAL_ALUMNOS=0
CANT_GRUPO1=0
CANT_GRUPO2=0
GRUPO_ACTUAL=""

# Leer el archivo de forma nativa línea por línea
while IFS= read -r linea || [ -n "$linea" ]; do
    # Limpiar espacios en blanco al inicio y final
    linea_limpia=$(echo "$linea" | xargs 2>/dev/null || echo "$linea")

    # Detectar el grupo
    if [[ "$linea_limpia" == "G1" ]]; then
        GRUPO_ACTUAL="G1"
        continue
    elif [[ "$linea_limpia" == "G2" ]]; then
        GRUPO_ACTUAL="G2"
        continue
    # Ignorar líneas vacías o etiquetas previas del final
    elif [[ -z "$linea_limpia" || "$linea_limpia" == "Fecha hora:"* || 
"$linea_limpia" == "Cantidad"* ]]; then
        continue
    fi

    # Si llegó aquí, es un nombre de alumno válido
    ((TOTAL_ALUMNOS++))
    
    if [[ "$GRUPO_ACTUAL" == "G1" ]]; then
        ((CANT_GRUPO1++))
    elif [[ "$GRUPO_ACTUAL" == "G2" ]]; then
        ((CANT_GRUPO2++))
    fi
done < 71alumnos.txt

# Obtener Fecha y Hora actual
FECHA_HORA=$(date "+%d/%m/%Y %H:%M:%S")

# Crear el archivo datos.log limpio con los resultados reales
echo "● Fecha hora: $FECHA_HORA" > datos.log
echo "● Cantidad de alumnos total: $TOTAL_ALUMNOS" >> datos.log
echo "● Cantidad grupo1: $CANT_GRUPO1" >> datos.log
echo "● Cantidad grupo2: $CANT_GRUPO2" >> datos.log

echo "✔ ¡Archivo 'datos.log' generado con éxito!"
echo "--- CONTENIDO DE DATOS.LOG ---"
cat datos.log
echo "------------------------------"
