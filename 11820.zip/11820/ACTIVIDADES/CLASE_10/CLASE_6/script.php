<?php
$mensaje = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['script']);
    $comandos = trim($_POST['command']);

    if (empty($nombre) || empty($comandos)) {
        $mensaje = "<b style='color:red;'>Ambas cajas deben tener 
contenido.</b>";
    } else {
        // Aseguramos que tenga la extensión .sh
        $archivoNombre = $nombre . ".sh";
        
        // Creamos el archivo con el contenido de los comandos
        $file = fopen($archivoNombre, "w");
        if ($file) {
            fwrite($file, $comandos);
            fclose($file);
            chmod($archivoNombre, 0777); // Damos permisos de ejecución
            $mensaje = "<b style='color:green;'>Script '$archivoNombre' 
generado con éxito.</b>";
        } else {
            $mensaje = "<b style='color:red;'>Error de permisos al crear 
el archivo.</b>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Generador de Scripts</title>
</head>
<body>
    <h2>Generador de Script Shell</h2>
    <form method="POST">
        <label>Script Name:</label><br>
        <input type="text" name="script" placeholder="ejemplo"><br><br>
        
        <label>Commands:</label><br>
        <textarea name="command" rows="5" cols="30"></textarea><br><br>
        
        <input type="submit" value="Generar Script">
    </form>
    <div style="margin-top:15px;"><?php echo $mensaje; ?></div>
</body>
</html>
