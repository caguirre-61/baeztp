#!/bin/bash

mkdir -p marionettes

echo 'echo "Hola soy Lima."' > marionettes/lime.sh
echo 'echo "Hola soy Cereza."' > marionettes/cherry.sh
echo 'echo "Hola soy Zarzamora."' > marionettes/bloodberry.sh

chmod +x marionettes/lime.sh
chmod +x marionettes/cherry.sh
chmod +x marionettes/bloodberry.sh

./marionettes/bloodberry.sh > teamj.txt

./marionettes/cherry.sh >> teamj.txt
./marionettes/lime.sh >> teamj.txt

echo "Proceso completado. Revisa el archivo teamj.txt"
