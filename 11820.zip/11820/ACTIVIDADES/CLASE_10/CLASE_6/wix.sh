#!/bin/bash

mkdir -p proyecto/css/user
mkdir -p proyecto/css/admin
mkdir -p proyecto/img/avatars
mkdir -p proyecto/img/buttons
mkdir -p proyecto/img/products
mkdir -p proyecto/img/pets
mkdir -p proyecto/js/validations
mkdir -p proyecto/js/effects
mkdir -p proyecto/tpl
mkdir -p proyecto/php

> proyecto/index.php
> proyecto/css/user/estilo.css
> proyecto/css/admin/estilo.css
> proyecto/js/validations/login.js
> proyecto/js/validations/register.js
> proyecto/js/effects/panels.js
> proyecto/tpl/main.tpl
> proyecto/tpl/login.tpl
> proyecto/tpl/register.tpl
> proyecto/tpl/panel.tpl
> proyecto/tpl/profile.tpl
> proyecto/tpl/crud.tpl
> proyecto/php/create.php
> proyecto/php/read.php
> proyecto/php/update.php
> proyecto/php/delete.php
> proyecto/php/dbconect.php

echo "Estructura de 'proyecto' creada con éxito usando redirección."
