#!/bin/bash
mkdir -p framework/app/http/controllers 
mkdir -p framework/app/http/models 
mkdir -p framework/database/mysqli 
mkdir -p framework/public 
mkdir -p framework/resources/css 
mkdir -p framework/resources/js 
mkdir -p framework/resources/views/landing 
mkdir -p framework/resources/views/notfound 
mkdir -p framework/router 
mkdir -p framework/vendor

> framework/.env framework/.gitignore framework/.htaccess 
> framework/README.md 
> framework/app/http/controllers/LandingController.php 
> framework/app/http/controllers/NotFoundController.php 
> framework/app/http/models/User.php 
> framework/app/http/models/Client.php 
> framework/database/mysqli/Connect.php framework/public/index.php 
> framework/resources/css/style.css framework/resources/js/defaul.js 
> framework/resources/views/landing/index.tpl.php 
> framework/resources/views/notfound/index.tpl.php 
> framework/router/RouterHandler.php
echo "Estructura de 'framework' finalizada con éxito."
