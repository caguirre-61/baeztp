<?php
date_default_timezone_set('America/Argentina/Buenos_Aires');

function registrarEvento($prefijo, $mensaje) {
    $archivoPath = 'navegacion.log';
    $fechaHora = date('Ymd_His');
    $ipCliente = $_SERVER['REMOTE_ADDR'];
    $navegador = isset($_SERVER['HTTP_USER_AGENT']) ? 
$_SERVER['HTTP_USER_AGENT'] : 'Desconocido';
    
    $linea = 
"{$prefijo}|{$fechaHora}|{$ipCliente}|{$navegador}|{$mensaje}" . 
PHP_EOL;
    
    $file = @fopen($archivoPath, 'a');
    if ($file) {
        fwrite($file, $linea);
        fclose($file);
    }
}

// Lógica para diferenciar ingreso de presión de botón
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['btnLogin'])) 
{
    registrarEvento('+', "anónimo presionó 'Login'.");
} else {
    registrarEvento('*', "anónimo ingreso a index.php.");
}

// Contador de eventos analizando el archivo
$ingresos = 0;
$logins = 0;

if (file_exists('navegacion.log')) {
    $lineas = file('navegacion.log');
    foreach ($lineas as $linea) {
        if (strpos($linea, '*') === 0) {
            $ingresos++;
        } elseif (strpos($linea, '+') === 0) {
            $logins++;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Sistema de Log - Clase 5</title>
</head>
<body>
    <form action="index.php" method="POST">
        <input type="submit" name="btnLogin" value="Login">
    </form>

    <div style="margin-top: 20px; font-family: sans-serif;">
        <p>Ingresos <?php echo $ingresos; ?></p>
        <p>Login <?php echo $logins; ?></p>
    </div>
</body>
</html>
