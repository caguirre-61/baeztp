<?php
// 1. Inicializar variables para evitar errores de "Undefined variable"
$nombreArchivo = "comandos_response_71_AGUIRRE_CAMILO.csv";
$totalCaracteres = 0;
$contadorComandos = 0;

// 2. Tu lógica principal
if (file_exists($nombreArchivo)) {
    $archivo = fopen($nombreArchivo, "r");

    while (!feof($archivo)) {
        $linea = fgets($archivo);

        // Filtramos: No vacía Y que contenga el asterisco
        if (!empty(trim($linea)) && strpos($linea, '*') !== false) {
            $totalCaracteres += strlen($linea);
            $contadorComandos++;

            $datos = explode(",", $linea);
            $comando = isset($datos[0]) ? trim($datos[0]) : "Sin 
comando";
            $resultado = isset($datos[1]) ? trim($datos[1]) : "";
            $resultadoLimpio = str_replace('*', '', $resultado);

            echo "<strong>" . htmlspecialchars($comando) . 
"</strong><br>";
            echo htmlspecialchars($resultadoLimpio) . "<br>";
            echo "<hr>";
        }
    }
    fclose($archivo);
} else {
    echo "Error: El archivo $nombreArchivo no existe.";
}

// 3. Pie de página
echo "<footer>
        <p>Comandos Listados: $contadorComandos</p>
        <p>Caracteres Leídos: $totalCaracteres</p>
        <p><strong>Alumno: Camilo Aguirre</strong><br>
        Asignatura: [IMRSC] / 2026</p>
      </footer>";
?>
