#!/bin/bash

if [ -z "$1" ]; then
    echo "Error: Falta el nombre o ubicación del proyecto."
    echo "Uso correcto: $0 <nombre_o_ruta_del_proyecto> [contenido_index]"
    exit 1
fi

PROYECTO="$1"
CONTENIDO_INDEX="$2" # Guardamos el segundo parámetro (puede ser opcional o venir vacío)

mkdir -p "$PROYECTO/css/user"
mkdir -p "$PROYECTO/css/admin"
mkdir -p "$PROYECTO/img/avatars"
mkdir -p "$PROYECTO/img/buttons"
mkdir -p "$PROYECTO/img/products"
mkdir -p "$PROYECTO/img/pets"
mkdir -p "$PROYECTO/js/validations"
mkdir -p "$PROYECTO/js/effects"
mkdir -p "$PROYECTO/tpl"
mkdir -p "$PROYECTO/php"

echo "$CONTENIDO_INDEX" > "$PROYECTO/index.php"

> "$PROYECTO/css/user/estilo.css"
> "$PROYECTO/css/admin/estilo.css"
> "$PROYECTO/js/validations/login.js"
> "$PROYECTO/js/validations/register.js"
> "$PROYECTO/js/effects/panels.js"
> "$PROYECTO/tpl/main.tpl"
> "$PROYECTO/tpl/login.tpl"
> "$PROYECTO/tpl/register.tpl"
> "$PROYECTO/tpl/panel.tpl"
> "$PROYECTO/tpl/profile.tpl"
> "$PROYECTO/tpl/crud.tpl"
> "$PROYECTO/php/create.php"
> "$PROYECTO/php/read.php"
> "$PROYECTO/php/update.php"
> "$PROYECTO/php/delete.php"
> "$PROYECTO/php/dbconect.php"

echo "Estructura de '$PROYECTO' creada con éxito."
if [ ! -z "$CONTENIDO_INDEX" ]; then
    echo "Se inyectó el contenido inicial en index.php."
fi
