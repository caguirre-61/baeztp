<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generador de Scripts</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 30px; 
            line-height: 1.6; 
        }
        .btn { 
            padding: 10px 20px; 
            font-size: 16px; 
            cursor: pointer; 
            background-color: #007bff; 
            color: white; 
            border: none; 
            border-radius: 4px; 
        }
        .btn-exec { 
            background-color: #28a745; 
        }
        .alert { 
            padding: 15px; 
            margin-bottom: 20px; 
            border: 1px solid transparent; 
            border-radius: 4px; 
        }
        .alert-success { 
            color: #155724; 
            background-color: #d4edda; 
            border-color: #c3e6cb; 
        }
        .alert-danger { 
            color: #721c24; 
            background-color: #f8d7da; 
            border-color: #f5c6cb; 
        }
        .terminal { 
            background-color: #1e1e1e; 
            color: #f1f1f1; 
            padding: 15px; 
            font-family: monospace; 
            border-radius: 5px; 
            overflow-x: auto; 
            white-space: pre-wrap; 
        }
    </style>
</head>
<body>

    <h1>Generador de Estructuras Web</h1>

    <?php
    $mostrar_boton_generar = true;
    $mostrar_seccion_ejecutar = false;
    $mostrar_resultado_terminal = false;
    $salida_terminal = '';

    if (isset($_POST['generar'])) {
        // Buscamos el archivo dentro de la carpeta "alumno" según la consigna
        $csv_path = '../alumno/71alumnos.csv';
        $script_path = 'newseven.sh';

        if (!file_exists($csv_path)) {
            echo "<div class='alert alert-danger'>Error: No se encontró el archivo en $csv_path</div>";
        } else {
            if (($file = fopen($csv_path, 'r')) !== FALSE) {
                $grupos = [];
                $alumnos = [];

                while (($data = fgetcsv($file, 1000, ",")) !== FALSE) {
                    $carnet = trim($data[0]);
                    $nombres = trim($data[1]);
                    $grupo = trim($data[2]);

                    // Saltamos la fila de cabecera si existe o si está vacía
                    if (empty($carnet) || strtolower($carnet) == 'carnet') {
                        continue;
                    }

                    // Guardamos los grupos de forma única para crearlos después
                    if (!in_array($grupo, $grupos) && !empty($grupo)) {
                        $grupos[] = $grupo;
                    }

                    // Reemplazamos espacios por guiones bajos
                    $nombres_limpios = str_replace(' ', '_', $nombres);

                    $alumnos[] = [
                        'carnet' => $carnet,
                        'nombres' => $nombres_limpios,
                        'grupo' => $grupo
                    ];
                }
                fclose($file);

                // Comenzamos a escribir el script de Bash
                $script_content = "#!/bin/bash\n\n";
                
                // Crea la carpeta principal
                $script_content .= "mkdir -p alumno\n\n";

                // Crea los subdirectorios de cada grupo encontrado (g1, g2, etc.)
                foreach ($grupos as $g) {
                    $script_content .= 'mkdir -p "alumno/' . $g . "\"\n";
                }
                $script_content .= "\n";

                // Procesa a los alumnos dentro de sus carpetas correspondientes
                foreach ($alumnos as $al) {
                    $grupo_al = $al['grupo'];
                    $carnet_al = $al['carnet'];
                    $nombre_al = $al['nombres'];

                    // Entramos al directorio del grupo
                    $script_content .= 'cd "alumno/' . $grupo_al . "\"\n";
                    // Ejecutamos wix.sh subiendo dos niveles (../../wix.sh) para encontrarlo en la raíz
                    $script_content .= '../../wix.sh "' . $carnet_al . '" "' . $nombre_al . "\"\n";
                    // Volvemos a la raíz del proyecto para la siguiente iteración
                    $script_content .= "cd ../..\n\n";
                }

                // Fin del script con el mensaje obligatorio
                $script_content .= "echo \"Ejecución finalizada.\"\n";

                // Guardamos el archivo y le asignamos permisos de ejecución
                file_put_contents($script_path, $script_content);
                chmod($script_path, 0755);

                $mostrar_boton_generar = false;
                $mostrar_seccion_ejecutar = true;
            } else {
                echo "<div class='alert alert-danger'>Error al abrir el archivo CSV.</div>";
            }
        }
    }

    if (isset($_POST['ejecutar'])) {
        $script_path = './newseven.sh';

        if (file_exists($script_path)) {
            // Ejecutamos el script y capturamos la salida estándar y de errores
            $salida_terminal = shell_exec("$script_path 2>&1");
            $mostrar_boton_generar = true;
            $mostrar_resultado_terminal = true;
        } else {
            echo "<div class='alert alert-danger'>Error: El script newseven.sh no existe.</div>";
        }
    }
    ?>

    <?php if ($mostrar_boton_generar): ?>
        <form action="" method="POST">
            <input type="submit" name="generar" class="btn" value="Generar">
        </form>
    <?php endif; ?>

    <?php if ($mostrar_seccion_ejecutar): ?>
        <div class="alert alert-success">
            CSV analizado, se creó el script newseven.sh para continuar presione 'ejecutar'.
        </div>
        <form action="" method="POST">
            <input type="submit" name="ejecutar" class="btn btn-exec" value="Ejecutar">
        </form>
    <?php endif; ?>

    <?php if ($mostrar_resultado_terminal): ?>
        <h2>Resultado en la página:</h2>
        <div class="terminal"><?php echo htmlspecialchars($salida_terminal); ?></div>
    <?php endif; ?>

</body>
</html>
