#!/bin/bash

mkdir -p alumno

mkdir -p "alumno/Aguirre Thomas Luka"
mkdir -p "alumno/Althaparro Simoni Gabriel"
mkdir -p "alumno/Andrada Julio Daniel"
mkdir -p "alumno/Baldini Guido Joaquin"
mkdir -p "alumno/Blenich Francisco Willy"
mkdir -p "alumno/Chaparro Guillermo Martin"
mkdir -p "alumno/Delport Franco Gabriel"
mkdir -p "alumno/Diaz Ian"
mkdir -p "alumno/Drobotij Leandro Nahuel"
mkdir -p "alumno/Faria Abril Victoria"
mkdir -p "alumno/Galarza Matias Emanuel"
mkdir -p "alumno/Garcia Francisco Gabriel"
mkdir -p "alumno/Gardey Juan Pablo"
mkdir -p "alumno/Gauto Santiago Luis"
mkdir -p "alumno/Gonzalez Brenda Camila"
mkdir -p "alumno/Gonzalez Franco Sebastian"
mkdir -p "alumno/Gonzalez Gaston"
mkdir -p "alumno/Herrera Lautaro Ezequiel"
mkdir -p "alumno/Jaimes Camila Antonella"
mkdir -p "alumno/Leiva Iara Eveleyn"
mkdir -p "alumno/Merino Brandon Ariel"
mkdir -p "alumno/Morales Kraff Ramiro Nazareno"
mkdir -p "alumno/Orellana Emir Isaac"
mkdir -p "alumno/Orrego Federico"
mkdir -p "alumno/Peloso Angel Federico"
mkdir -p "alumno/Ramirez Alan Ezequiel"
mkdir -p "alumno/Santana Deumal Francisco"
mkdir -p "alumno/Silva Roberto Elian"
mkdir -p "alumno/Sosa Pickman Marcos Emanuel"
mkdir -p "alumno/Toconas Ignacio Gabriel"
mkdir -p "alumno/Waszczuk Ania"
mkdir -p "alumno/Zapata Tomas Agustin"

cd "alumno/Aguirre Thomas Luka"
../../wix.sh "3658" "G2"
cd ../..
cd "alumno/Althaparro Simoni Gabriel"
../../wix.sh "3610" "G1"
cd ../..
cd "alumno/Andrada Julio Daniel"
../../wix.sh "3631" "G2"
cd ../..
cd "alumno/Baldini Guido Joaquin"
../../wix.sh "3655" "G2"
cd ../..
cd "alumno/Blenich Francisco Willy"
../../wix.sh "7187" "G1"
cd ../..
cd "alumno/Chaparro Guillermo Martin"
../../wix.sh "3561" "G2"
cd ../..
cd "alumno/Delport Franco Gabriel"
../../wix.sh "3591" "G1"
cd ../..
cd "alumno/Diaz Ian"
../../wix.sh "3613" "G2"
cd ../..
cd "alumno/Drobotij Leandro Nahuel"
../../wix.sh "3616" "G1"
cd ../..
cd "alumno/Faria Abril Victoria"
../../wix.sh "3827" "G1"
cd ../..
cd "alumno/Galarza Matias Emanuel"
../../wix.sh "7118" "G1"
cd ../..
cd "alumno/Garcia Francisco Gabriel"
../../wix.sh "3734" "G2"
cd ../..
cd "alumno/Gardey Juan Pablo"
../../wix.sh "3635" "G2"
cd ../..
cd "alumno/Gauto Santiago Luis"
../../wix.sh "3662" "G2"
cd ../..
cd "alumno/Gonzalez Brenda Camila"
../../wix.sh "3921" "G1"
cd ../..
cd "alumno/Gonzalez Franco Sebastian"
../../wix.sh "3623" "G1"
cd ../..
cd "alumno/Gonzalez Gaston"
../../wix.sh "3657" "G2"
cd ../..
cd "alumno/Herrera Lautaro Ezequiel"
../../wix.sh "3555" "G1"
cd ../..
cd "alumno/Jaimes Camila Antonella"
../../wix.sh "3608" "G2"
cd ../..
cd "alumno/Leiva Iara Eveleyn"
../../wix.sh "3619" "G1"
cd ../..
cd "alumno/Merino Brandon Ariel"
../../wix.sh "3639" "G2"
cd ../..
cd "alumno/Morales Kraff Ramiro Nazareno"
../../wix.sh "3659" "G1"
cd ../..
cd "alumno/Orellana Emir Isaac"
../../wix.sh "3627" "G2"
cd ../..
cd "alumno/Orrego Federico"
../../wix.sh "3946" "G1"
cd ../..
cd "alumno/Peloso Angel Federico"
../../wix.sh "3629" "G1"
cd ../..
cd "alumno/Ramirez Alan Ezequiel"
../../wix.sh "7071" "G2"
cd ../..
cd "alumno/Santana Deumal Francisco"
../../wix.sh "3661" "G1"
cd ../..
cd "alumno/Silva Roberto Elian"
../../wix.sh "3644" "G1"
cd ../..
cd "alumno/Sosa Pickman Marcos Emanuel"
../../wix.sh "3621" "G2"
cd ../..
cd "alumno/Toconas Ignacio Gabriel"
../../wix.sh "3638" "G1"
cd ../..
cd "alumno/Waszczuk Ania"
../../wix.sh "3654" "G2"
cd ../..
cd "alumno/Zapata Tomas Agustin"
../../wix.sh "3670" "G2"
cd ../..

echo "Ejecucion finalizada."
